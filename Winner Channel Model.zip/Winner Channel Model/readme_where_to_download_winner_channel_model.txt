Please download Winner+ II channel model from http://projects.celtic-initiative.org/winner+/Documents/Publications/WIM2_3D_ant_ver064_220908.zip
and extract it into this folder

References

[1] L. Hentil�, P. Ky�sti, M. K�ske, M. Narandzic , and M. Alatossava. (2007, December.) MATLAB implementation of the WINNER Phase II 
Channel Model ver1.1 [Online]. Available: http://projects.celtic-initiative.org/winner+/phase_2_model.html