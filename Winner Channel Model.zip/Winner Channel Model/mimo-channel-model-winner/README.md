# mimo-channel-model-winner
This repo includes the channel model code from winner project
